import numpy as np

import numpy as np
from scipy.interpolate import interp1d

def count_lines_in_datasets(file_names):
    """
    依次读取每个文件，计算其中每个数据集包含多少行。数据集之间由两行空白行分割。
    
    参数：
    file_names (list): 包含文件名称的列表。
    
    返回：
    list: 一个包含所有数据集行数的列表，按文件顺序和数据集顺序排列。
    """
    all_datasets_lines = []

    # 依次处理每个文件
    for file_name in file_names:
        try:
            with open(file_name, 'r') as f:
                content = f.read()

            # 去掉文件开头和结尾的空白行
            content = content.strip()

            # 使用 '\n\n' 来分割数据集，假设每个数据集之间由两行空白行分割
            datasets = content.split('\n\n')

            # 对每个数据集，计算其行数并添加到结果列表
            for dataset in datasets:
                # 统计当前数据集的行数
                dataset_lines = len(dataset.strip().split('\n'))
                all_datasets_lines.append(dataset_lines)

        except FileNotFoundError:
            print(f"文件 {file_name} 未找到！")
        except Exception as e:
            print(f"处理文件 {file_name} 时出现错误: {e}")

    return all_datasets_lines

class Infor_Y:
    def __init__(self, cross_section_data, efficiency_data, stopping_power_data):
        # 数据初始化和插值对象的创建
        ug = 1e-6
        barn = 1e-24
        NA = 6.02e23
        target_element_percent = 1
        target_nuclide_percent = 0.99
        A_target = 13.0033548
        a_beam = 4.002603254
        self.Eupb = 3
        self.Elwb = 0.0
        self.dE = 1e-4
        self.interval = 1e-3
        self.n = ug * target_element_percent * target_nuclide_percent * NA / A_target
        self.barn = barn

        # 假设 cross_section_data, efficiency_data 和 stopping_power_data 是每个数据文件的 (x, y) 数据对
        cross_section_data['x']=cross_section_data['x'] * (A_target+a_beam) / A_target # convert to ELab(MeV)
        stopping_power_data['x']=stopping_power_data['x'] / 1000 # convert to ELab(MeV)
        stopping_power_data['y']=stopping_power_data['y'] / 1000 # convert to MeV/(ug/cm2)
        self.gr_cs = interp1d(cross_section_data['x'], cross_section_data['y'], kind='linear', fill_value="extrapolate")
        self.gr_eff = interp1d(efficiency_data['x'], efficiency_data['y'], kind='linear', fill_value="extrapolate")
        self.gr_dE = interp1d(stopping_power_data['x'], stopping_power_data['y'], kind='linear', fill_value="extrapolate")

        # 用于存储计算的产额数据
        self.gr_yield = []

    def Cal_yield(self):
        Energy = 1e-6
        Yield = 0
        iN = 0

        while Energy < self.Eupb:
            cs = self.gr_cs(Energy)
            eff = self.gr_eff(Energy)
            stop = self.gr_dE(Energy)
            Yield += cs * self.barn * eff * (self.n / stop) * self.dE
            Energy += self.dE

            # 当 Energy 到达 Elwb 时，开始记录产额
            if iN == 0 and Energy >= self.Elwb:
                self.gr_yield.append((Energy, Yield))
                iN += 1

            # 当能量变化超过设定的间隔时，添加新的数据点
            if iN > 0 and Energy - self.gr_yield[iN - 1][0] > self.interval:
                self.gr_yield.append((Energy, Yield))
                iN += 1



def read_cross_section(file_path):
    """
    读取截面文件，提取第一列和第四列数据（能量和截面）。
    """
    data = np.loadtxt(file_path)  # 默认按空格或制表符分隔
    x_values = data[:, 0]  # 第一列 unit Ecm(MeV)
    y_values = data[:, 3]  # 第四列 unit barn
    return x_values, y_values

def read_efficiency(file_path):
    """
    读取效率文件，提取第一列和第二列数据（能量和效率）。
    """
    data = np.loadtxt(file_path)  # 默认按空格或制表符分隔
    x_values = data[:, 0]  # 第一列 unit Elab(MeV)
    y_values = data[:, 1]  # 第二列 nounit
    return x_values, y_values

def read_stopping_power(file_path):
    """
    读取阻止本领文件，提取第一列和第二列+第三列之和作为y值。
    """
    data = np.loadtxt(file_path)  # 默认按空格或制表符分隔
    x_values = data[:, 0]  # 第一列 unit Elab(keV)
    y_values = data[:, 1] + data[:, 2]  # 第二列和第三列之和unit keV/(ug/cm2)
    return x_values, y_values

def read_exp_yield():
    """
    读取阻止本领文件，提取第一列和第二列+第三列之和作为y值。
    """
    file_path = "data_calculate_yield/C13an_Exp_JUNA_Thick_Yield_20240823.dat"
    data = np.loadtxt(file_path)  # 默认按空格或制表符分隔
    x_values = data[:, 0]  # 第一列 unit Elab(MeV)
    y_values = data[:, 1] # 第二列 unit /mC
    y_values_err = data[:, 1] * data[:,2]/100 # absolute error
    return x_values, y_values, y_values_err

def load_data(cross_section, efficiency_file, stopping_power_file, cross_section_is_file=True):
    """
    加载所有数据文件，返回包含x和y值的字典。

    参数：
    cross_section_file (str): 截面文件路径。
    efficiency_file (str): 效率文件路径。
    stopping_power_file (str): 阻止本领文件路径。

    返回：
    dict: 包含从每个文件提取的x和y值。
    """
    data = {}

    # 读取截面文件
    if cross_section_is_file:
        x_cs, y_cs = read_cross_section(cross_section)  # 假设 `cross_section` 是文件路径
    else:
        # cross_section 是 ndarray 或类似数据，提取 x 和 y
        x_cs = cross_section[:, 0]
        y_cs = cross_section[:, 3]
    data['cross_section'] = {'x': x_cs, 'y': y_cs}

    # 读取效率文件
    x_eff, y_eff = read_efficiency(efficiency_file)
    data['efficiency'] = {'x': x_eff, 'y': y_eff}

    # 读取阻止本领文件
    x_dE, y_dE = read_stopping_power(stopping_power_file)
    data['stopping_power'] = {'x': x_dE, 'y': y_dE}

    return data

def calculate_yield(extrap):

    # 示例调用
#    cross_section_file = "data_calculate_yield/AZUREOut_aa=2_R=1.extrap"
    efficiency_file = "data_calculate_yield/efficiency_new2024.txt"
    stopping_power_file = "data_calculate_yield/He_in_C13_stop.txt"

#    data = load_data(cross_section_file, efficiency_file, stopping_power_file)
    data = load_data(extrap, efficiency_file, stopping_power_file, cross_section_is_file=False)

    # 然后你可以初始化 Infor_Y 类并计算产额
    infor_y = Infor_Y(data['cross_section'], data['efficiency'], data['stopping_power'])
    infor_y.Cal_yield()
#    np.set_printoptions(threshold=np.inf)
#    print(np.array(infor_y.gr_yield))
    return infor_y.gr_yield

def calculate_chi_square(calY):
    """
    计算 CalY 和实验数据之间的卡方。

    返回：
    float: 计算得到的卡方值。
    """
    energy_cal = np.array([point[0] for point in calY])
    yield_cal = np.array([point[1] for point in calY])
    x_expY, y_expY, y_err_expY = read_exp_yield()
    y_expY = y_expY / (1e-3/1.6e-19) # unit /mC -> /cnt
    y_err_expY = y_err_expY / (1e-3/1.6e-19)
    gr_yield_interpolator = interp1d(energy_cal, yield_cal, kind='linear', fill_value="extrapolate")

    # 插值结果
    interpolated_yield = gr_yield_interpolator(x_expY)

    # 计算卡方
    chi_square = np.sum(((interpolated_yield - y_expY) ** 2) / (y_err_expY ** 2))
#    print(interpolated_yield, y_expY)
    
    return chi_square, len(x_expY)

