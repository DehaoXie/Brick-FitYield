import numpy as np
import dill
import matplotlib.pyplot as plt
from scipy.interpolate import interp1d
from brick.azr import AZR
import test_iminuit as ti
import calculate_yield as cy
from test_iminuit import func
import calculate_yield as cy

# In []
azr = AZR('Draw_Fit.azr')
azr.root_directory = '/tmp/'
output_filename = ti.output_filename

theta0 = azr.config.get_input_values()
#func(theta0)

filename="fit_results.pkl"
with open(filename, "rb") as f:
    results = dill.load(f)
# 假设 results 是一个包含多个 result 对象的列表
for result in results:
    if hasattr(result, 'values') and hasattr(result, 'fval'):
#        print(result.values)
        print(result.fval)
#        func(result.values)

# 在计算最小 fval 之前过滤掉不包含 'values' 和 'fval' 的结果
filtered_results = [result for result in results if hasattr(result, 'values') and hasattr(result, 'fval')]

if filtered_results:  # 确保有合法的结果
    min_fval_result = min(filtered_results, key=lambda result: result.fval)
    min_fval_values = np.array(min_fval_result.values)
else:
    print("No valid results with 'values' and 'fval'.")
# 打印出 fval 最小的结果及其 values
print("Min fval result values:", min_fval_values)
print("Min fval:", min_fval_result.fval)
print("theta0:", np.array(theta0))
print(np.array(min_fval_values/theta0))

# In []
# get .out data with order of (n,n)->(n,a)->(a,n)
theta = min_fval_values
#input_filename, output_dir, output_files = azr.config.generate_workspace_extrap(theta)
#print(input_filename)
output = np.vstack( azr.predict( theta, dress_up=False) )
extrap = azr.extrapolate(theta)
sole_datalines = cy.count_lines_in_datasets(output_filename)
if len(azr.config.data.segments) != len(sole_datalines):
   raise ValueError(f"Error: The number of segments ({len(azr.config.data.segments)}) does not match the expected number of data lines ({sole_datalines}).")

# Now we loop over the data files to take their order and length and cut the output
index, data = 0, { }
for i in range(0,len(sole_datalines)):
    data[i] = output[index:index+sole_datalines[i]]
    index += sole_datalines[i]

# In []
data_name = ['Fowler', 'Cierjacks', 'SCU21-Thick', 'SCU21-Thin', 'SCU24-Thick', 'SCU24-Thin']
data_ = {}
for i in range(0,2):
    data_[data_name[i]] = data[i+2][:,[0,7,8]]

for i in range(4,len(sole_datalines)):
    data_[data_name[i-2]] = data[i][:,[0,7,8]]
# nt = nn+na
extrap_nt = [extrap[1][:,0], extrap[0][:,4]+extrap[1][:,4]]
extrap_an = [extrap[2][:,0], extrap[2][:,4]]
# calculate theory yield
calY = cy.calculate_yield(extrap[2])
calY=np.array(calY)
calY=[calY[:,0], calY[:,1]]
x_expY, y_expY, y_err_expY = cy.read_exp_yield()
y_expY = y_expY / (1e-3/1.6e-19) # unit /mC -> /cnt
y_err_expY = y_err_expY / (1e-3/1.6e-19)
print(calY[0])

# In []
# 插值函数（线性插值）
def interpolate_extrap(x_data, extrap_data):
    interp_func = interp1d(extrap_data[0], extrap_data[1], kind='linear', fill_value="extrapolate")
    return interp_func(x_data)

# 归一化函数
def normalize_to_baseline(x_data, y_data, y_error, extrap_data):
    # 对 y 数据进行插值并归一化
    baseline_y = interpolate_extrap(x_data, extrap_data)
    normalized_y = y_data / baseline_y
    normalized_error = y_error / baseline_y
    return normalized_y, normalized_error

massa=4.002603
mass13C=13.003355
dQ = 2.2156106
xmin = -0.6
xmax =2.5

fig, axs = plt.subplots(2, 1, figsize=(12, 12))
axs[0].errorbar(x_expY*mass13C/(massa+mass13C), y_expY, yerr=y_err_expY, label='exp', fmt='o', capsize=5, markersize=5, linestyle='None')
axs[0].plot(calY[0]*mass13C/(massa+mass13C), calY[1], label='fit', color='black', linestyle='--', linewidth=2)

axs[0].set_xlim(0.2, 0.65)
axs[0].set_ylim(1e-22, 1e-10)
axs[0].set_yscale('log')
axs[0].set_ylabel('Yield/cnt')
axs[0].set_title('Integrated yield vs exp yield')
axs[0].legend()
axs[0].grid(True)

normalized_y, normalized_error = normalize_to_baseline(x_expY, y_expY, y_err_expY, calY)

# 绘制归一化后的数据
axs[1].errorbar(x_expY*mass13C/(massa+mass13C), normalized_y, yerr=normalized_error, label=f'exp (Normalized)', fmt='o', capsize=5, markersize=5, linestyle='None')
    
axs[1].set_xlim(0.2, 0.65)
axs[1].set_ylim(0.85, 1.4)
axs[1].axhline(y=1, color='red', linestyle='--', label='Baseline y=1')  # 基准线 y=1
axs[1].set_xlabel('Ecm (MeV)')
axs[1].set_ylabel('Residual')
axs[1].set_title('Integrated yield vs exp yield')
axs[1].legend()
axs[1].grid(True)

plt.tight_layout()
plt.show(block=False)

# 第一张图：Fowler 和 Cierjacks 的 nt 数据与 extrap_nt
fig, axs = plt.subplots(2, 1, figsize=(12, 12))

# nt 数据：Fowler 和 Cierjacks 与 extrap_nt
for i in range(0,2):
    label = data_name[i]
    x_data = data_[label][:, 0]  # x 数据
    y_data = data_[label][:, 1]  # y 数据
    y_errors = data_[label][:, 2]  # 误差数据（假设数据的第三列是误差）

    # 将nt数据与extrap_nt绘制在同一张图
    axs[0].errorbar(x_data-dQ, y_data, yerr=y_errors, label=label, fmt='o', capsize=5, markersize=5, linestyle='None')  # 'o'表示数据点，'None'表示不连接线

# extrap_nt 数据
x_extrap_nt = extrap_nt[0]  # x 数据
y_extrap_nt = extrap_nt[1]  # y 数据
axs[0].plot(x_extrap_nt-dQ, y_extrap_nt, label='extrap_nt', color='black', linestyle='--', linewidth=2)  # extrap_nt 用虚线表示

axs[0].set_xlim(xmin, xmax)
axs[0].set_yscale('log')
axs[0].set_ylabel('S-factor (MeV b')
axs[0].set_title('nt Data (Fowler & Cierjacks) vs Extrapolated nt')
axs[0].legend()
axs[0].grid(True)

# an 数据：SCU21 和 SCU24 与 extrap_an
for i in range(4,len(sole_datalines)):
    label = data_name[i-2]
    x_data = data_[label][:, 0]  # x 数据
    y_data = data_[label][:, 1]  # y 数据
    y_errors = data_[label][:, 2]  # 误差数据（假设数据的第三列是误差）

    # 将an数据与extrap_an绘制在同一张图
    axs[1].errorbar(x_data, y_data, yerr=y_errors, label=label, fmt='o', capsize=5, markersize=5, linestyle='None')  # 'o'表示数据点，'None'表示不连接线

# extrap_an 数据
x_extrap_an = extrap_an[0]  # x 数据
y_extrap_an = extrap_an[1]  # y 数据
axs[1].plot(x_extrap_an, y_extrap_an, label='extrap_an', color='black', linestyle='--', linewidth=2)  # extrap_an 用虚线表示

axs[1].set_xlim(xmin, xmax)
axs[1].set_yscale('log')
axs[1].set_xlabel('Em (MeV)')
axs[1].set_ylabel('S-factor (MeV b')
axs[1].set_title('an Data (SCU21 & SCU24) vs Extrapolated an')
axs[1].legend()
axs[1].grid(True)

plt.tight_layout()
plt.show(block=False)

# In []
# residule

fig, axs = plt.subplots(2, 1, figsize=(12, 12))

# nt 数据：Fowler 和 Cierjacks 与 extrap_nt
for i in range(0,2):
    label = data_name[i]
    x_data = data_[label][:, 0]  # x 数据
    y_data = data_[label][:, 1]  # y 数据
    y_errors = data_[label][:, 2]  # 误差数据（假设数据的第三列是误差）

    normalized_y, normalized_error = normalize_to_baseline(x_data, y_data, y_errors, extrap_nt)

     # 绘制归一化后的数据
    axs[0].errorbar(x_data-dQ, normalized_y, yerr=normalized_error, label=f'{label} (Normalized)', fmt='o', capsize=5, markersize=5, linestyle='None')

axs[0].set_xlim(xmin, xmax)
axs[0].axhline(y=1, color='red', linestyle='--', label='Baseline y=1')  # 基准线 y=1
axs[0].set_ylabel('Residual')
axs[0].set_title('nt Data (Fowler & Cierjacks) vs Extrapolated nt')
axs[0].legend()
axs[0].grid(True)

# 第二张图：SCU21 和 SCU24 的 an 数据与 extrap_an

# an 数据：SCU21 和 SCU24 与 extrap_an
for i in range(4,len(sole_datalines)):
    label = data_name[i-2]
    x_data = data_[label][:, 0]  # x 数据
    y_data = data_[label][:, 1]  # y 数据
    y_errors = data_[label][:, 2]  # 误差数据（假设数据的第三列是误差）

    normalized_y, normalized_error = normalize_to_baseline(x_data, y_data, y_errors, extrap_an)

     # 绘制归一化后的数据
    axs[1].errorbar(x_data, normalized_y, yerr=normalized_error, label=f'{label} (Normalized)', fmt='o', capsize=5, markersize=5, linestyle='None')
    
axs[1].set_xlim(xmin, xmax)
axs[1].axhline(y=1, color='red', linestyle='--', label='Baseline y=1')  # 基准线 y=1
axs[1].set_xlabel('Ecm (MeV)')
axs[1].set_ylabel('Residual')
axs[1].set_title('an Data (SCU21 & SCU24) vs Extrapolated an')
axs[1].legend()
axs[1].grid(True)

plt.tight_layout()
plt.show()
