import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
import calculate_yield as cy
import datetime
import dill

from tqdm import tqdm
from brick.azr import AZR
from lmfit import Parameters, Minimizer
from IPython.display import display, Math
from multiprocess import Pool
from iminuit import Minuit

# Ignore RuntimeWarning
import warnings
warnings.filterwarnings("ignore", category=RuntimeWarning)

# Normalization parameter map : { index : (value, error) } (in AZURE2 order)
norms = { 0: (1.0343, 1), 1: (1.0485, 1), 2: (1., 0.11), 3: (1., 0.11), 4: (1., 0.11), 5: (1., 0.11), 6: (1, 0.11) }
output_filename = ['output/AZUREOut_aa=1_R=1.out', 'output/AZUREOut_aa=1_R=2.out', 'output/AZUREOut_aa=2_R=1.out']

# We read the .azr file
azr = AZR('Start_Fit.azr')
azr.root_directory = '/tmp/'

# We get the initial values from AZURE2
theta0 = azr.config.get_input_values()

def func(theta):
    # Get number of data points
    output = np.vstack( azr.predict( theta, dress_up=False) )
    extrap = azr.extrapolate(theta)

    # input 13Can extrapolation
    calY = cy.calculate_yield(extrap[0])
#    print(np.array(extrap[2]))

    chi2_Y, num_expY = cy.calculate_chi_square(calY)
#    print(chi2_Y, num_expY)

    sole_datalines = cy.count_lines_in_datasets(output_filename)
    if len(azr.config.data.segments) != len(sole_datalines):
       raise ValueError(f"Error: The number of segments ({len(azr.config.data.segments)}) does not match the expected number of data lines ({sole_datalines}).")

    nsegments = len(sole_datalines)
    # Now we loop over the data files to take their order and length and cut the output
    index, data = 0, { }
    for i in range(0,len(sole_datalines)):
        data[i] = output[index:index+sole_datalines[i]]
        index += sole_datalines[i]
#        print(data[i][:,0])
#        print('\n\n')

    # Number of R-matrix parameters (without normalization)
    # There are 2 segments without normalization
    ntheta = len(theta) - nsegments + 2

    chi2=0
    # i+2 -> n,a channel
    # i -> n,n channel
    for i in range(0,2):
        chi2_nt=sum(((data[i+2][:,5]-data[i+2][:,3]-data[i][:,3])/data[i+2][:,6])**2)
        chi2_norms=( (theta[ntheta+i]-norms[i][0])/(norms[i][0]*norms[i][1]) )**2
        num_data=len(data[i+2][:,5])
        chi2=chi2+chi2_nt+chi2_norms
#        print(f"chi2_norms = {chi2_norms}")
#        print(f"theta {theta[ntheta+i]}")
#        print(f"norm {norms[i][0]}")
#        print(f"(chi2_nt+chi2_norms)/num_data = {(chi2_nt)/num_data}")

    # There are 2 segments without normalization
    for i in range(4,len(sole_datalines)):
        chi2_13C=sum(((data[i][:,5]-data[i][:,3])/data[i][:,6])**2)
        chi2_norms=( (theta[ntheta+i-2]-norms[i-2][0])/(norms[i-2][0]*norms[i-2][1]) )**2
        num_data=len(data[i][:,5])
        chi2=chi2+chi2_13C+chi2_norms
#        print(f"chi2_norms = {chi2_norms}")
#        print(f"theta {theta[ntheta+i-2]}")
#        print(f"norm {norms[i-2][0]}")
#        print(f"(chi2_13C+chi2_norms)/num_data = {(chi2_13C)/num_data}")

    chi2=chi2+chi2_Y
    print(f"chi2_Y = {chi2_Y}")
    print(f"chi2 = {chi2}")
    if np.isnan(chi2):
        chi2 = 1e100  # 强制返回一个很大的数
#    chi2=1 # fast converge
    return chi2

#func(theta0)

# To run many parallel minimizations
def run_minimization( seed ):
    np.random.seed( seed )
    initial_guess = np.array( theta0 )
    for i in range( len(theta0) ):
        initial_guess[i] = np.random.uniform( theta0[i] * 0.9999, theta0[i] * 1.0001 )
    params = Parameters()
    for i in range(len(theta0)):
        params.add( "param_{}".format(i), value=initial_guess[i], vary=True, min=-np.inf, max=np.inf)
    mini = Minuit( func, params)
    try:
        out = mini.migrad()  # 进行最小化
    except Exception as e:
        print(f"Minuit migration failed: {e}")
        # 返回一个标志值或默认值，以表示出错
        out = None  
    return out

if __name__=="__main__":
    start_time = datetime.datetime.now() 
    print("Start time:", start_time)
    
    # Number of parallel minimizations
    #help(Minuit)
    nparallel = 55
    with Pool( nparallel ) as pool:
        results = list( tqdm( pool.imap_unordered( run_minimization, range(nparallel) ), total=nparallel ) )
    
    filename="fit_results.pkl"
    with open(filename, "wb") as f:
        dill.dump(results, f)
        print(f"Results saved to {filename}")
    
    end_time = datetime.datetime.now()
    print("End time:", end_time)
    
    
